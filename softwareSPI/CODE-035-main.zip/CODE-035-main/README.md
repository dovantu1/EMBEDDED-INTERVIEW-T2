# CODE-035
[Tự học proteus] Hướng dẫn cài thư viện và mô phỏng Arduino trên Proteus (cho Win 10) || VTM https://www.youtube.com/watch?v=PFXKjnV0hdc&amp;t=1s
